import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ApiService } from '../services/api.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { inject } from '@angular/core/testing';
import { MatTableDataSource } from '@angular/material/table';
import { AppComponent } from '../app.component';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.css']
})
export class DialogComponent implements OnInit {

  gender: string[] = ['Male', 'Female', 'Others',];
  studentform !: FormGroup;
  ActionBtn: string = "save"
  dialog: any;
  dataSource!: MatTableDataSource<any>;
  paginator: any;
  sort: any;
  router: any;





  constructor(private formBuilder: FormBuilder,
    private activatedRoute: ActivatedRoute,
    private api: ApiService,
    @Inject(MAT_DIALOG_DATA) public editData: any,
    private dialogref: MatDialogRef<DialogComponent>) { }
    
    

  ngOnInit(): void {
    

    this.studentform = this.formBuilder.group({
      studentName: ['', [Validators.required, Validators.maxLength(10)]],
      studentId: ['', [Validators.required, Validators.pattern("[0-9]{6}")]],
      emailId: ['', [Validators.required, Validators.email]],
      gender: ['', Validators.required],
      city: ['', Validators.required],
      pincode: ['', [Validators.required, Validators.pattern("[0-9]{6}")]],
      grade:['',[Validators.required, Validators.pattern("[0-12]{2}")]],
      mobilenumber: ['', [Validators.required, Validators.pattern("[0-9]{10}")]],

    });
    
   


    if (this.editData) {
      this.ActionBtn = "Update";
      this.studentform.controls['studentName'].setValue(this.editData.studentName);
      this.studentform.controls['studentId'].setValue(this.editData.studentId);
      this.studentform.controls['emailId'].setValue(this.editData.emailId);
      this.studentform.controls['gender'].setValue(this.editData.gender);
      this.studentform.controls['city'].setValue(this.editData.city);
      this.studentform.controls['pincode'].setValue(this.editData.pincode);
      this.studentform.controls['gender'].setValue(this.editData.gender);
      this.studentform.controls['mobilenumber'].setValue(this.editData.mobilenumber);
    }
  } 




  adddetails() {
   
    if (!this.editData) {
      if (this.studentform.valid) {

        this.api.postStudent(this.studentform.value).subscribe({
          next: (res) => {

            this.studentform.reset();
            this.dialogref.close();
            window.location.reload()
            
          },
          error: () => {
            alert("Error while adding the sudentdetails")

          }
        })



      }
    } else {
      this.updateStudent()
    }
  

    
  }

  
  updateStudent() {
    this.api.putStudent(this.studentform.value, this.editData.id).subscribe({
      next: (res) => {
        alert("Studendetails updated successfully");
        this.studentform.reset();
        this.dialogref.close('update');

 
      },
      error: () => {
        alert("error while getting the record");
      }
    })


  }
  getAllStudents() {
    this.api.getStudent().subscribe((res) => {
      this.dataSource = new MatTableDataSource(res);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;



    })
    

  }
  get studentName() {

    return this.studentform.get('studentName');

  }

  get studentId() {

    return this.studentform.get('studentId');

  }
  get emailId() {

    return this.studentform.get('emailId');

  }
  get pincode() {

    return this.studentform.get('pincode');

  }
  get grade() {

    return this.studentform.get('grade');

  }
  get mobilenumber() {

    return this.studentform.get('mobilenumber');

  }


}


